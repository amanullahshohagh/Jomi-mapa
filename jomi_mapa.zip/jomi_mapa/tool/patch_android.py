"""Patches the generated android/ folder: permissions, app label, minSdk."""
import re, pathlib, sys

root = pathlib.Path(__file__).resolve().parent.parent
mf = root / 'android/app/src/main/AndroidManifest.xml'
s = mf.read_text(encoding='utf-8')

perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
]
add = ''.join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in s)
if add:
    s = s.replace('<application', add + '    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="জমি মাপা"', s, count=1)
mf.write_text(s, encoding='utf-8')

for name in ('build.gradle', 'build.gradle.kts'):
    g = root / 'android/app' / name
    if g.exists():
        t = g.read_text(encoding='utf-8')
        t = re.sub(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion',
                   lambda m: 'minSdk = 21' if name.endswith('.kts') else 'minSdkVersion 21', t)
        g.write_text(t, encoding='utf-8')
print('android patched')
