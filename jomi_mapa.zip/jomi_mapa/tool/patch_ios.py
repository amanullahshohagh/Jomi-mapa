import pathlib
p = pathlib.Path(__file__).resolve().parent.parent / 'ios/Runner/Info.plist'
if p.exists():
    s = p.read_text(encoding='utf-8')
    if 'NSLocationWhenInUseUsageDescription' not in s:
        s = s.replace('</dict>\n</plist>',
            '\t<key>NSLocationWhenInUseUsageDescription</key>\n'
            '\t<string>জমি মাপার জন্য আপনার লোকেশন দরকার</string>\n</dict>\n</plist>')
        p.write_text(s, encoding='utf-8')
    print('ios patched')
