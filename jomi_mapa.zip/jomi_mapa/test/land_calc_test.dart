import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:jomi_mapa/core/land_calc.dart';

void main() {
  test('about 100m x 100m square is ~10,000 m²', () {
    // 0.0009 deg lat ~ 100 m; lng scaled by cos(lat)
    const lat = 23.8;
    final dLng = 0.0009 / 0.9150; // cos(23.8°) ≈ 0.915
    final pts = [
      const LatLng(lat, 90.4),
      const LatLng(lat + 0.0009, 90.4),
      LatLng(lat + 0.0009, 90.4 + dLng),
      LatLng(lat, 90.4 + dLng),
    ];
    final a = polygonAreaSqm(pts);
    expect(a, closeTo(10000, 400));
  });

  test('less than 3 points gives 0', () {
    expect(polygonAreaSqm(const [LatLng(1, 1), LatLng(2, 2)]), 0);
  });
}
