@echo off
REM One-time setup (Windows). Requires Flutter SDK in PATH and Python 3.
cd /d %~dp0
call flutter create . --org com.jomimapa --project-name jomi_mapa --platforms=android,ios
python tool\patch_android.py
python tool\patch_ios.py
call flutter pub get
call dart run flutter_launcher_icons
echo Done. Run:  flutter run   ^|   APK:  flutter build apk --release
pause
