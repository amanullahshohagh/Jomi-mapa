#!/usr/bin/env bash
# One-time setup (Mac/Linux). Requires Flutter SDK in PATH.
set -e
cd "$(dirname "$0")"
flutter create . --org com.jomimapa --project-name jomi_mapa --platforms=android,ios
python3 tool/patch_android.py
python3 tool/patch_ios.py
flutter pub get
dart run flutter_launcher_icons
echo "Done. Run:  flutter run   |  APK:  flutter build apk --release"
