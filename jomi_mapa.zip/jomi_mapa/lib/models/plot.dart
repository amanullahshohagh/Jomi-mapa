import 'package:latlong2/latlong.dart';

class Plot {
  final String id;
  String name;
  final List<LatLng> points;
  final DateTime createdAt;

  Plot({required this.id, required this.name, required this.points, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'points': points.map((p) => [p.latitude, p.longitude]).toList(),
      };

  factory Plot.fromJson(Map<String, dynamic> j) => Plot(
        id: j['id'],
        name: j['name'],
        createdAt: DateTime.parse(j['createdAt']),
        points: (j['points'] as List)
            .map((e) => LatLng((e[0] as num).toDouble(), (e[1] as num).toDouble()))
            .toList(),
      );
}
