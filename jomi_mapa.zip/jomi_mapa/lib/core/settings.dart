import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// App-wide settings. Katha/Bigha vary by region, so the user can edit them.
class AppSettings extends ChangeNotifier {
  double kathaSqFt = 720; // 1 কাঠা = ? বর্গফুট
  double bighaKatha = 20; // 1 বিঘা = ? কাঠা

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    kathaSqFt = p.getDouble('kathaSqFt') ?? 720;
    bighaKatha = p.getDouble('bighaKatha') ?? 20;
  }

  Future<void> update({double? kathaSqFt, double? bighaKatha}) async {
    if (kathaSqFt != null && kathaSqFt > 0) this.kathaSqFt = kathaSqFt;
    if (bighaKatha != null && bighaKatha > 0) this.bighaKatha = bighaKatha;
    final p = await SharedPreferences.getInstance();
    await p.setDouble('kathaSqFt', this.kathaSqFt);
    await p.setDouble('bighaKatha', this.bighaKatha);
    notifyListeners();
  }
}

final AppSettings settings = AppSettings();
