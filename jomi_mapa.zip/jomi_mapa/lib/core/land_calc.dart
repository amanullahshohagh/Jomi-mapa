import 'dart:math';
import 'package:latlong2/latlong.dart';
import 'settings.dart';

const double _sqFtInSqm = 0.09290304;
const double _shatakSqm = 40.4686;
const double _acreSqm = 4046.8564224;

/// Area of a polygon (GPS points) in square meters.
/// Uses a local flat projection + shoelace formula (good for plots up to a few km).
double polygonAreaSqm(List<LatLng> pts) {
  if (pts.length < 3) return 0;
  const r = 6371008.8;
  final lat0 = pts.map((p) => p.latitude).reduce((a, b) => a + b) / pts.length;
  final cosLat0 = cos(lat0 * pi / 180);
  final xy = pts
      .map((p) => [r * (p.longitude * pi / 180) * cosLat0, r * (p.latitude * pi / 180)])
      .toList();
  double sum = 0;
  for (var i = 0; i < xy.length; i++) {
    final j = (i + 1) % xy.length;
    sum += xy[i][0] * xy[j][1] - xy[j][0] * xy[i][1];
  }
  return sum.abs() / 2;
}

/// Perimeter in meters.
double perimeterM(List<LatLng> pts) {
  if (pts.length < 2) return 0;
  const d = Distance();
  double total = 0;
  for (var i = 0; i < pts.length; i++) {
    total += d(pts[i], pts[(i + 1) % pts.length]);
  }
  return total;
}

class AreaResult {
  final double sqm;
  final double sqFt;
  final double shatak;
  final double katha;
  final double bigha;
  final double acre;
  final double hectare;

  AreaResult._(this.sqm, this.sqFt, this.shatak, this.katha, this.bigha, this.acre, this.hectare);

  factory AreaResult.fromSqm(double sqm) {
    final kathaSqm = settings.kathaSqFt * _sqFtInSqm;
    final bighaSqm = kathaSqm * settings.bighaKatha;
    return AreaResult._(
      sqm,
      sqm / _sqFtInSqm,
      sqm / _shatakSqm,
      sqm / kathaSqm,
      sqm / bighaSqm,
      sqm / _acreSqm,
      sqm / 10000,
    );
  }

  /// Ordered label -> value, for display.
  Map<String, double> get all => {
        'শতক': shatak,
        'কাঠা': katha,
        'বিঘা': bigha,
        'একর': acre,
        'বর্গফুট': sqFt,
        'বর্গমিটার': sqm,
        'হেক্টর': hectare,
      };
}

String fmt(double v) {
  if (v >= 1000) return v.toStringAsFixed(0);
  if (v >= 10) return v.toStringAsFixed(2);
  return v.toStringAsFixed(3);
}
