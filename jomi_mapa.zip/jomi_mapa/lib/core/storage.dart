import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/plot.dart';

class PlotStorage {
  static const _key = 'plots_v1';

  static Future<List<Plot>> all() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    final list = (jsonDecode(raw) as List).map((e) => Plot.fromJson(e)).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  static Future<void> _write(List<Plot> plots) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(plots.map((e) => e.toJson()).toList()));
  }

  static Future<void> save(Plot plot) async {
    final plots = await all();
    final i = plots.indexWhere((e) => e.id == plot.id);
    if (i >= 0) {
      plots[i] = plot;
    } else {
      plots.add(plot);
    }
    await _write(plots);
  }

  static Future<void> delete(String id) async {
    final plots = await all();
    plots.removeWhere((e) => e.id == id);
    await _write(plots);
  }
}
