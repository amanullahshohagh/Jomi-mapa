import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:latlong2/latlong.dart';
import 'land_calc.dart';

/// Builds a Bangla PDF report (Noto Sans Bengali bundled in assets) and opens the share sheet.
Future<void> sharePlotPdf(String name, List<LatLng> pts) async {
  final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansBengali-Regular.ttf'));
  final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansBengali-Bold.ttf'));

  final area = AreaResult.fromSqm(polygonAreaSqm(pts));
  final per = perimeterM(pts);
  final title = name.isEmpty ? 'নামহীন জমি' : name;

  final doc = pw.Document(theme: pw.ThemeData.withFont(base: regular, bold: bold));
  doc.addPage(pw.Page(
    build: (ctx) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text('জমির মাপের রিপোর্ট',
          style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 6),
      pw.Text('জমি: $title', style: const pw.TextStyle(fontSize: 14)),
      pw.Text('তারিখ: ${DateTime.now().toString().substring(0, 16)}'),
      pw.SizedBox(height: 16),
      pw.TableHelper.fromTextArray(
        headers: ['একক', 'পরিমাণ'],
        headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
        data: area.all.entries.map((e) => [e.key, fmt(e.value)]).toList(),
      ),
      pw.SizedBox(height: 12),
      pw.Text('পরিসীমা: ${per.toStringAsFixed(1)} মিটার'),
      pw.SizedBox(height: 12),
      pw.Text('কোণার স্থানাঙ্ক:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
      ...List.generate(
        pts.length,
        (i) => pw.Text(
            '${i + 1}. ${pts[i].latitude.toStringAsFixed(6)}, ${pts[i].longitude.toStringAsFixed(6)}'),
      ),
      pw.Spacer(),
      pw.Text('এটি GPS/ম্যাপ থেকে আনুমানিক মাপ। আইনি কাজে সরকারি জরিপই গ্রহণযোগ্য।',
          style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
    ]),
  ));

  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/jomi_mapa_report.pdf');
  await file.writeAsBytes(await doc.save());
  await Share.shareXFiles([XFile(file.path)], text: 'জমির মাপ: $title');
}
