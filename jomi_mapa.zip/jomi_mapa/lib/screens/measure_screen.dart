import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import '../core/land_calc.dart';
import 'result_screen.dart';

enum MeasureMode { map, walk }

class MeasureScreen extends StatefulWidget {
  const MeasureScreen({super.key});

  @override
  State<MeasureScreen> createState() => _MeasureScreenState();
}

class _MeasureScreenState extends State<MeasureScreen> {
  final MapController _map = MapController();
  final List<LatLng> _pts = [];
  MeasureMode _mode = MeasureMode.map;
  bool _satellite = true;
  LatLng? _me;
  double? _accuracy;
  StreamSubscription<Position>? _sub;

  @override
  void initState() {
    super.initState();
    _startLocation(moveCamera: true);
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<bool> _ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _snack('ফোনের লোকেশন (GPS) চালু করুন');
      return false;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _snack('লোকেশন পারমিশন দিতে হবে');
      return false;
    }
    return true;
  }

  Future<void> _startLocation({bool moveCamera = false}) async {
    if (!await _ensurePermission()) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.best));
      _me = LatLng(pos.latitude, pos.longitude);
      _accuracy = pos.accuracy;
      if (moveCamera) _map.move(_me!, 18);
      if (mounted) setState(() {});
    } catch (_) {}
    _sub?.cancel();
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best, distanceFilter: 1),
    ).listen((pos) {
      if (!mounted) return;
      setState(() {
        _me = LatLng(pos.latitude, pos.longitude);
        _accuracy = pos.accuracy;
      });
    });
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _addMyPoint() {
    if (_me == null) {
      _snack('GPS লোকেশন পাওয়া যায়নি, একটু অপেক্ষা করুন');
      return;
    }
    if (_accuracy != null && _accuracy! > 15) {
      _snack('GPS নির্ভুলতা কম (±${_accuracy!.toStringAsFixed(0)} মি.)। খোলা জায়গায় গিয়ে আবার চেষ্টা করুন।');
    }
    setState(() => _pts.add(_me!));
  }

  @override
  Widget build(BuildContext context) {
    final area = polygonAreaSqm(_pts);
    final r = AreaResult.fromSqm(area);

    return Scaffold(
      appBar: AppBar(
        title: const Text('জমি মাপুন'),
        actions: [
          IconButton(
            icon: Icon(_satellite ? Icons.map : Icons.satellite_alt),
            tooltip: 'ম্যাপ/স্যাটেলাইট',
            onPressed: () => setState(() => _satellite = !_satellite),
          ),
          IconButton(
            icon: const Icon(Icons.my_location),
            tooltip: 'আমার অবস্থান',
            onPressed: () async {
              await _startLocation();
              if (_me != null) _map.move(_me!, 18);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: const LatLng(23.685, 90.356), // Bangladesh
                initialZoom: 7,
                maxZoom: 20,
                onTap: (_, point) {
                  if (_mode == MeasureMode.map) setState(() => _pts.add(point));
                },
              ),
              children: [
                TileLayer(
                  urlTemplate: _satellite
                      ? 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
                      : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.jomi_mapa',
                  maxNativeZoom: 19,
                  maxZoom: 20,
                ),
                if (_pts.length >= 3)
                  PolygonLayer(polygons: [
                    Polygon(
                      points: _pts,
                      color: Colors.green.withOpacity(0.3),
                      isFilled: true,
                      borderColor: Colors.yellowAccent,
                      borderStrokeWidth: 3,
                    ),
                  ]),
                if (_pts.length == 2)
                  PolylineLayer(polylines: [
                    Polyline(points: _pts, color: Colors.yellowAccent, strokeWidth: 3),
                  ]),
                MarkerLayer(markers: [
                  for (var i = 0; i < _pts.length; i++)
                    Marker(
                      point: _pts[i],
                      width: 26,
                      height: 26,
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: Text('${i + 1}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  if (_me != null)
                    Marker(
                      point: _me!,
                      width: 22,
                      height: 22,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                        ),
                      ),
                    ),
                ]),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              boxShadow: const [BoxShadow(blurRadius: 6, color: Colors.black26)],
            ),
            child: SafeArea(
              top: false,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                SegmentedButton<MeasureMode>(
                  segments: const [
                    ButtonSegment(
                        value: MeasureMode.map,
                        icon: Icon(Icons.touch_app),
                        label: Text('ম্যাপে ট্যাপ')),
                    ButtonSegment(
                        value: MeasureMode.walk,
                        icon: Icon(Icons.directions_walk),
                        label: Text('GPS হাঁটা')),
                  ],
                  selected: {_mode},
                  onSelectionChanged: (s) => setState(() => _mode = s.first),
                ),
                const SizedBox(height: 8),
                Text(
                  _mode == MeasureMode.map
                      ? 'জমির প্রতিটি কোণায় ম্যাপে ট্যাপ করুন'
                      : 'জমির প্রতিটি কোণায় দাঁড়িয়ে "পয়েন্ট যোগ করুন" চাপুন'
                          '${_accuracy != null ? "  (GPS ±${_accuracy!.toStringAsFixed(0)} মি.)" : ""}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13),
                ),
                const SizedBox(height: 6),
                Text(
                  _pts.length < 3
                      ? 'পয়েন্ট: ${_pts.length} (কমপক্ষে ৩টি লাগবে)'
                      : '${fmt(r.shatak)} শতক • ${fmt(r.katha)} কাঠা • ${fmt(r.bigha)} বিঘা',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  if (_mode == MeasureMode.walk)
                    Expanded(
                      child: FilledButton.tonalIcon(
                        onPressed: _addMyPoint,
                        icon: const Icon(Icons.add_location),
                        label: const Text('পয়েন্ট যোগ করুন'),
                      ),
                    ),
                  if (_mode == MeasureMode.walk) const SizedBox(width: 8),
                  IconButton.filledTonal(
                    onPressed: _pts.isEmpty ? null : () => setState(() => _pts.removeLast()),
                    icon: const Icon(Icons.undo),
                    tooltip: 'শেষ পয়েন্ট বাতিল',
                  ),
                  IconButton.filledTonal(
                    onPressed: _pts.isEmpty ? null : () => setState(_pts.clear),
                    icon: const Icon(Icons.delete_outline),
                    tooltip: 'সব মুছুন',
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _pts.length < 3
                          ? null
                          : () async {
                              final saved = await Navigator.push<bool>(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => ResultScreen(points: List.of(_pts))),
                              );
                              if (saved == true && mounted) Navigator.pop(context);
                            },
                      icon: const Icon(Icons.check),
                      label: const Text('শেষ'),
                    ),
                  ),
                ]),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
