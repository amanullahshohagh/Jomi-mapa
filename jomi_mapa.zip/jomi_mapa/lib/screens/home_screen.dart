import 'package:flutter/material.dart';
import '../core/land_calc.dart';
import '../core/storage.dart';
import '../models/plot.dart';
import 'measure_screen.dart';
import 'result_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Plot> plots = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await PlotStorage.all();
    if (mounted) setState(() => plots = p);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('জমি মাপা'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'সেটিংস',
            onPressed: () async {
              await Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
              setState(() {});
            },
          ),
        ],
      ),
      body: plots.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'এখনো কোনো জমি সেভ করা নেই।\nনিচের বাটনে চাপ দিয়ে নতুন জমি মাপুন।',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
              ),
            )
          : ListView.builder(
              itemCount: plots.length,
              itemBuilder: (_, i) {
                final p = plots[i];
                final a = AreaResult.fromSqm(polygonAreaSqm(p.points));
                return Dismissible(
                  key: ValueKey(p.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  confirmDismiss: (_) async =>
                      await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('মুছে ফেলবেন?'),
                          content: Text('"${p.name}" মুছে যাবে।'),
                          actions: [
                            TextButton(
                                onPressed: () => Navigator.pop(c, false),
                                child: const Text('না')),
                            TextButton(
                                onPressed: () => Navigator.pop(c, true),
                                child: const Text('হ্যাঁ')),
                          ],
                        ),
                      ) ??
                      false,
                  onDismissed: (_) async {
                    await PlotStorage.delete(p.id);
                    _load();
                  },
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.landscape)),
                    title: Text(p.name),
                    subtitle: Text(
                        '${fmt(a.shatak)} শতক • ${fmt(a.katha)} কাঠা • ${fmt(a.bigha)} বিঘা'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ResultScreen(points: p.points, plot: p)),
                      );
                      _load();
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add_location_alt),
        label: const Text('নতুন জমি মাপুন'),
        onPressed: () async {
          await Navigator.push(
              context, MaterialPageRoute(builder: (_) => const MeasureScreen()));
          _load();
        },
      ),
    );
  }
}
