import 'package:flutter/material.dart';
import '../core/settings.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _katha =
      TextEditingController(text: settings.kathaSqFt.toString());
  late final TextEditingController _bigha =
      TextEditingController(text: settings.bighaKatha.toString());

  @override
  void dispose() {
    _katha.dispose();
    _bigha.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'কাঠা ও বিঘার মাপ এলাকাভেদে আলাদা। আপনার এলাকার মান এখানে দিন।',
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _katha,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: '১ কাঠা = কত বর্গফুট',
              helperText: 'ঢাকা: ৭২০, অনেক জেলায়: ৭২০ বা ৮৬৪ ইত্যাদি',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _bigha,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: '১ বিঘা = কত কাঠা',
              helperText: 'সাধারণত ২০ কাঠা',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () async {
              await settings.update(
                kathaSqFt: double.tryParse(_katha.text.trim()),
                bighaKatha: double.tryParse(_bigha.text.trim()),
              );
              if (!context.mounted) return;
              Navigator.pop(context);
            },
            child: const Text('সেভ করুন'),
          ),
        ],
      ),
    );
  }
}
