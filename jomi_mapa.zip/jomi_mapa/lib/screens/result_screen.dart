import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/land_calc.dart';
import '../core/pdf_export.dart';
import '../core/storage.dart';
import '../models/plot.dart';

class ResultScreen extends StatefulWidget {
  final List<LatLng> points;
  final Plot? plot; // existing saved plot (if opened from list)

  const ResultScreen({super.key, required this.points, this.plot});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late final TextEditingController _name;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.plot?.name ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim().isEmpty ? 'নামহীন জমি' : _name.text.trim();
    final plot = widget.plot ??
        Plot(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          name: name,
          points: widget.points,
          createdAt: DateTime.now(),
        );
    plot.name = name;
    await PlotStorage.save(plot);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে')));
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final sqm = polygonAreaSqm(widget.points);
    final area = AreaResult.fromSqm(sqm);
    final per = perimeterM(widget.points);

    return Scaffold(
      appBar: AppBar(title: const Text('ফলাফল')),
      body: ListView(
        children: [
          SizedBox(
            height: 220,
            child: FlutterMap(
              options: MapOptions(
                initialCameraFit: CameraFit.coordinates(
                  coordinates: widget.points,
                  padding: const EdgeInsets.all(40),
                ),
                interactionOptions: const InteractionOptions(flags: InteractiveFlag.none),
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
                  userAgentPackageName: 'com.example.jomi_mapa',
                  maxNativeZoom: 19,
                ),
                PolygonLayer(polygons: [
                  Polygon(
                    points: widget.points,
                    color: Colors.green.withOpacity(0.35),
                    isFilled: true,
                    borderColor: Colors.yellowAccent,
                    borderStrokeWidth: 3,
                  ),
                ]),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _name,
              decoration: const InputDecoration(
                labelText: 'জমির নাম (যেমন: বাড়ির পাশের জমি)',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          for (final e in area.all.entries)
            ListTile(
              dense: true,
              title: Text(e.key),
              trailing: Text(fmt(e.value),
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ListTile(
            dense: true,
            title: const Text('পরিসীমা (মিটার)'),
            trailing: Text(per.toStringAsFixed(1),
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'এটি GPS/ম্যাপ থেকে আনুমানিক মাপ। আইনি কাজে সরকারি জরিপই গ্রহণযোগ্য।',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => sharePlotPdf(_name.text.trim(), widget.points),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('PDF শেয়ার'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save),
                  label: const Text('সেভ করুন'),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
